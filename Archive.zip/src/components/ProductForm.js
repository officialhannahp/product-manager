import React, { useState } from 'react'
import axios from 'axios';

const ProductForm = () => {
    const [product, setProduct] = useState({
        title: '',
        price: Number,
        desc: ''
    })

    const submitHandler = e => {
        e.preventDefault();
        axios.post('http://localhpst:8000/api/products', product)
            .then(res => console.log(res))
            .catch(err => console.log(err))
    }

    const changeHandler = e => {
        setProduct({ ...product, [e.target.name]: e.target.value });
    }

    return (
        <>
            <form onSubmit={ submitHandler }>
                <div>
                    <label htmlFor="title">Title: </label>
                    <input type="text" name="title" onChange={changeHandler}/>
                </div>
                <div>
                    <label htmlFor="price">Price: </label>
                    <input type="number" name="price" onChange={changeHandler}/>
                </div>
                <div>
                    <label htmlFor="desc">Description: </label>
                    <input type="text" name="desc" onChange={changeHandler}/>
                </div>
                <input type="submit" value="Create" />
            </form>
        </>
    )
}

export default ProductForm
